package com.example.example4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Created by oserh on 5/25/2016.
 */
public class importdata {
    public static String[] apload(int numTypes){
        String[] apTable = new String[numTypes];
        try{
            FileReader fileReader = new FileReader("C:\\Users\\oserh\\Desktop\\testtable\\topAp.dat"); //mac address base
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line = null;
            while((line = bufferedReader.readLine())!=null){
                /* System.out.println(line); */
                String[] lineSplit = line.split(" ");
                for(int i=0; i<numTypes; i++) {
                    apTable[i] = lineSplit[i];
                }
            }
            bufferedReader.close();
        }catch(IOException ex){
            System.out.println("error");
        }
        return apTable;
    }

    public static float[][] fileload(String fileName){
        float[][] rssTable = new float[2][150];
        //float[] item = new float[300];
        try{
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line = null;
            int cellIndex = 0;
            while((line = bufferedReader.readLine())!=null){
                /* System.out.println(line); */
                String[] lineSplit = line.split(",");
                for(int i=0; i<150; i++)
                {
                    rssTable[cellIndex][i] = Float.parseFloat(lineSplit[i]);
                    //System.out.println(rssTable[cellIndex][i]);
                }
                cellIndex++;
                    //System.out.println("one line over");
                }
                bufferedReader.close();
            }catch(IOException ex){
                System.out.println("error");
            }
            return rssTable;
        }

    }

package com.example.example4;

import java.util.List;
import android.app.Activity;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener {
		public WifiManager wifiManager;
		private TextView textRssi;
		Button buttonRssi;

		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);

			textRssi = (TextView) findViewById(R.id.textRSSI);
			buttonRssi = (Button) findViewById(R.id.buttonRSSI);
			buttonRssi.setOnClickListener(this);
		}

		// onResume() register the accelerometer for listening the events
		protected void onResume() {
			super.onResume();
		}

		// onPause() unregister the accelerometer for stop listening the events
		protected void onPause() {
			super.onPause();
		}

		@Override
		public void onClick(View v) {
			//textRssi.setText("\n\tScan all access points:");
			wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
			wifiManager.startScan();
			List<ScanResult> scanResult = wifiManager.getScanResults();
			//for (int i = 0; i < scanResult.size(); i++) {
			//	textRssi.setText(textRssi.getText() + "\n\tBSSID = "
			//			+ scanResult.get(i).BSSID + "    RSSI = "
			//			+ scanResult.get(i).level + "dBm");
			//}

			int types = 40, numCells=18;
			String[] ap;
			ap = new String[types]; // 40 is the number of mac address
			ap[] = importdata.apload(types);

			float[] freq;
			freq = new float[2];
			for(int l=0; l<numCells; l++ )
			{
				freq[l] = 1/numCells ;
			}
			float sum_freq = 0,  max_freq=1/numCells;
			int location = 0;
			//String s;
			//s = String.valueOf(ap_001a30c1dfd2[0][79]);
			//textRssi.setText(s);
			for(int i = 0; i < scanResult.size(); i++) {
				for (int j = 0; j < types; j++) {
					if (scanResult.get(i).BSSID.equals(ap[j])) {
						String file = "C:\\Users\\oserh\\Desktop\\testtable\\" + ap[j] + ".dat";
						float[][] ap_temp = importdata.fileload(file);
						freq[j] *= ap_temp[j][scanResult.get(i).level];
						sum_freq += freq[j];
					}
					else
						textRssi.setText("No match mac addiress");
				}
			}

			for (int k = 0; k < numCells; k++) {
				freq[k] /= sum_freq;
			}
			for(int g=1; g<numCells; g++) {
				if (freq[g] > max_freq) {
					max_freq = freq[g];
					location = g;
				}
			}
			textRssi.setText("\n\tI am in Cell" + location);
			}
		}
}


// Smart phone sensing course example code 4...
